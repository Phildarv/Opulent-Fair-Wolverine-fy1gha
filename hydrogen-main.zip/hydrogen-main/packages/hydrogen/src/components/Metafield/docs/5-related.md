## Related components

- [`ProductMetafield`](/api/hydrogen/components/product-variant/productmetafield)
