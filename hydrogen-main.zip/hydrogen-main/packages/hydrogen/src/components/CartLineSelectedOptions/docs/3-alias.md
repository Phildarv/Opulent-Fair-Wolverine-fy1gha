## Alias

The `CartLineSelectedOptions` component is aliased by the `CartLine.SelectedOptions` component. You can use whichever component you prefer.
