## Alias

The `SelectedVariantAddToCartButton` component is aliased by the `Product.SelectedVariant.AddToCartButton` component. You can use whichever component you prefer.
