export {SelectedVariantAddToCartButton} from './SelectedVariantAddToCartButton.client';
