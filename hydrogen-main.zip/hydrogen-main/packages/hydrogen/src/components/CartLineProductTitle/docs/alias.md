## Alias

The `CartLineProductTitle` component is aliased by the `CartLine.ProductTitle` component. You can use whichever component you prefer.
