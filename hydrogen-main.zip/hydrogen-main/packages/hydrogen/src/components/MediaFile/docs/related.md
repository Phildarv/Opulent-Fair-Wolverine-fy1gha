## Related components

- [`Image`](/api/hydrogen/components/primitive/image)
- [`Video`](/api/hydrogen/components/primitive/video)
- [`ExternalVideo`](/api/hydrogen/components/primitive/externalvideo)
- [`Model3D`](/api/hydrogen/components/primitive/model3d)
