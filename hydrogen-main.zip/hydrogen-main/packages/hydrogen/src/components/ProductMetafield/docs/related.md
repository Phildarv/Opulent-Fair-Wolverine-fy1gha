## Related components

- [`Metafield`](/api/hydrogen/components/primitive/metafield)
