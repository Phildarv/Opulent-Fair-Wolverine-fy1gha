export {ProductMetafield} from './ProductMetafield.client';
export type {ProductMetafieldProps} from './ProductMetafield.client';
