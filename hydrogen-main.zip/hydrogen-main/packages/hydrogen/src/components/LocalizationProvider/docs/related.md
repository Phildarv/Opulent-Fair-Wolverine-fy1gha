## Related hooks

- [`useCountry`](/api/hydrogen/hooks/localization/usecountry)
- [`useAvailableCountries`](/api/hydrogen/hooks/localization/useavailablecountries)
