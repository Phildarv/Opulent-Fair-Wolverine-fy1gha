export {CartShopPayButton} from './CartShopPayButton.client';
