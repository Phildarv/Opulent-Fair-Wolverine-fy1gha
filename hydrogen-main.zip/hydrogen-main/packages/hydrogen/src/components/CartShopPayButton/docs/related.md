## Related components

- [ShopPayButton](/api/hydrogen/components/primitive/shoppaybutton)
