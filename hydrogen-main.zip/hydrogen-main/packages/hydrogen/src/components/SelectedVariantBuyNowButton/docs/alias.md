## Alias

The `SelectedVariantBuyNowButton` component is aliased by the `Product.SelectedVariant.BuyNowButton` component. You can use whichever component you prefer.
