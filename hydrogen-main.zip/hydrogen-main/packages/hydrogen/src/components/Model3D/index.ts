export {Model3D, Model3DProps} from './Model3D.client';
