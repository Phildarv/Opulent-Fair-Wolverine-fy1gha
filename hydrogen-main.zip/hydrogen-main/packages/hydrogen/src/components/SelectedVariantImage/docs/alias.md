## Alias

The `SelectedVariantImage` component is aliased by the `Product.SelectedVariant.Image` component. You can use whichever component you prefer.
