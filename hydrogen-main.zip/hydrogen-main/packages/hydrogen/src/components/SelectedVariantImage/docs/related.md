## Related components

- [`ProductProvider`](/api/hydrogen/components/product-variant/productprovider)
- [`Image`](/api/hydrogen/components/primitive/image)

## Related hooks

- [`useProductOptions`](/api/hydrogen/hooks/product-variant/useproductoptions)
