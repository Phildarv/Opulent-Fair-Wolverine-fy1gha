## Alias

The `CartLineImage` component is aliased by the `CartLine.Image` component. You can use whichever component you prefer.
