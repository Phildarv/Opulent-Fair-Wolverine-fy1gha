## Alias

The `ProductTitle` component is aliased by the `Product.Title` component. You can use whichever component you prefer.
