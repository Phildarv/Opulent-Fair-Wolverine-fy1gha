export {ProductTitle} from './ProductTitle.client';
