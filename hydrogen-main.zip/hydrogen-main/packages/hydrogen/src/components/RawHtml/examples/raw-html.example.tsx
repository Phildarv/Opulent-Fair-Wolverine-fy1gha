import {RawHtml} from '@shopify/hydrogen';

export function MyComponent() {
  return <RawHtml string="<p>Hello world</p>" />;
}
