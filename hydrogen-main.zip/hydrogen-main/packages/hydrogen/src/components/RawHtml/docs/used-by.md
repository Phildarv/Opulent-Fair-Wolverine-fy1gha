## Used by

- [`ProductDescription`](/api/hydrogen/components/product-variant/productdescription)
