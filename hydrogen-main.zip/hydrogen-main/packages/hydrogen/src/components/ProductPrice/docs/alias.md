## Alias

The `ProductPrice` component is aliased by the `Product.Price` component. You can use whichever component you prefer.
