export {ProductPrice} from './ProductPrice.client';
