## Alias

The `ProductProvider` component is aliased by the `Product` component. You can use whichever component you prefer.
