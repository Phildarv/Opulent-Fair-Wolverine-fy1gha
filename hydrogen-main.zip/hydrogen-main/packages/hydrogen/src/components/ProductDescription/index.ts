export {ProductDescription} from './ProductDescription.client';
