## Related components

- [`CartLineAttributes`](/api/hydrogen/components/cart/cartlineattributes)
- [`CartLineImage`](/api/hydrogen/components/cart/cartlineimage)
- [`CartLinePrice`](/api/hydrogen/components/cart/cartlineprice)
- [`CartLineProvider`](/api/hydrogen/components/cart/cartlineprovider)
- [`CartLineProductTitle`](/api/hydrogen/components/cart/cartlineproducttitle)
- [`CartLineQuantity`](/api/hydrogen/components/cart/cartlinequantity)
- [`CartLineQuantityAdjustButton`](/api/hydrogen/components/cart/cartlinequantityadjustbutton)
- [`CartLineSelectedOptions`](/api/hydrogen/components/cart/cartlineselectedoptions)

## Related hooks

- [`useCartLine`](/api/hydrogen/hooks/cart/usecart)
