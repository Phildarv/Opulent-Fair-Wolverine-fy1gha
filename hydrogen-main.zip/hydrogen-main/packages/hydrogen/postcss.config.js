module.exports = {
  plugins: [
    // eslint-disable-next-line node/no-extraneous-require
    require('autoprefixer'),
    require('tailwindcss'),
  ],
};
