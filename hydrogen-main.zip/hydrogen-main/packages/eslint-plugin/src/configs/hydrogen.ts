export default {
  plugins: ['hydrogen'],
  rules: {
    'hydrogen/no-state-in-server-components': 'error',
    'hydrogen/prefer-image-component': 'error',
  },
};
