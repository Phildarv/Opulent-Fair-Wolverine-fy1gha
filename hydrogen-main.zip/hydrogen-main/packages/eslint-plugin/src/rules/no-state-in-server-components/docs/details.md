## Rule Details

This rule prevents using these hooks in files that do not end with the `.client` suffix that denotes a React Component that does not run on the server.
