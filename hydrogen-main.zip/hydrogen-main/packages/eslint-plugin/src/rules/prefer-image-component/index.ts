export {preferImageComponent} from './prefer-image-component';
