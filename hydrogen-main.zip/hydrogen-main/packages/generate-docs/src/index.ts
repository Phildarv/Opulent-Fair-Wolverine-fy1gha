export {DocsGen, Options} from './DocsGen';
