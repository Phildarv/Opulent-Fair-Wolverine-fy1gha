<!-- This file is generated from the source code. Edit the files in /packages/cli/src/commands/create/app and run 'yarn generate-docs' at the root of this repo. -->

Configure, modify and scaffold new `@shopify/hydrogen` apps.

## Example code

```bash
h2 create app
```
