export default function () {
  return `
  export default function About() {
    return (
      <div className="Page">
        <h1>
          About
        </h1>
        <p>Share your journey.</p>
      </div>
    );
  }
  `;
}
