export {component as default} from './component';
