export {Fs, FileResult} from './fs';
