export class NotImplementedError extends Error {}
export class InputError extends Error {}
export class UnknownError extends Error {}
