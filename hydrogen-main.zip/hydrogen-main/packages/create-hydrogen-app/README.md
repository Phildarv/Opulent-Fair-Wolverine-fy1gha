# create-hydrogen-app

Create a new [Hydrogen](https://www.npmjs.com/package/@shopify/hydrogen) project:

```bash
npm init hydrogen-app@latest
```

Or with yarn:

```bash
yarn create hydrogen-app
```
