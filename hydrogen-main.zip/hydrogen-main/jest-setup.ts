import '@shopify/react-testing';
import '@shopify/react-testing/matchers';
import '@testing-library/jest-dom';
import './scripts/polyfillWebRuntime';
